SELECT article.category, article.articleID, article.title 
FROM article, student
WHERE article.articleID
AND article.category = "Biography";
