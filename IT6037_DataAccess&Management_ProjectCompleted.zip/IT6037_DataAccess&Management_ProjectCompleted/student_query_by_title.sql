SELECT article.category, article.articleID, article.title 
FROM article
WHERE article.articleID
AND article.title = "Mona Lisa";
